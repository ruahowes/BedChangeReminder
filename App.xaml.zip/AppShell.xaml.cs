﻿namespace BedChangeReminder
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
        }

        public AppShell(MainPage mainPage)
        {
            InitializeComponent();
            this.Items.Add(new ShellContent { Content = mainPage });
        }
    }
}
