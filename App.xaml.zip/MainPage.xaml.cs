﻿using CommunityToolkit.Maui.Views;
using Microsoft.Maui.Controls;
using BedChangeReminder.Views;

namespace BedChangeReminder
{
    public partial class MainPage : ContentPage
    {
        public MainViewModel ViewModel { get; }

        public MainPage(MainViewModel viewModel)
        {
            InitializeComponent();
            ViewModel = viewModel;
            BindingContext = ViewModel;

            var listView = new ListView
            {
                ItemsSource = viewModel.Beds,
                ItemTemplate = new DataTemplate(() =>
                {
                    var nameLabel = new Label { FontSize = 18 };
                    nameLabel.SetBinding(Label.TextProperty, "Name");

                    var previousChangeLabel = new Label();
                    previousChangeLabel.SetBinding(Label.TextProperty, new Binding("LastChangeDate", stringFormat: "Last Change: {0:MMM dd}"));

                    var nextChangeLabel = new Label();
                    nextChangeLabel.SetBinding(Label.TextProperty, new Binding("NextChangeDate", stringFormat: "Next Change: {0:MMM dd} ({1})"));

                    var logButton = new Button { Text = "Log Change" };
                    logButton.SetBinding(Button.CommandParameterProperty, new Binding("."));
                    logButton.SetBinding(Button.CommandProperty, new Binding("LogBedChangeCommand"));

                    return new ViewCell { View = new StackLayout { Padding = 10, Children = { nameLabel, previousChangeLabel, nextChangeLabel, logButton } } };
                })
            };

            var addBedButton = new Button { Text = "Add Bed" };
            addBedButton.SetBinding(Button.CommandProperty, "AddBedCommand");

            Content = new StackLayout { Padding = 20, Children = { addBedButton, listView } };
            ViewModel = viewModel;
        }

        // Open Popup when "Add Bed" is clicked
        private async void OnAddBedClicked(object sender, EventArgs e)
        {
            var popup = new BedPopup
            {
                OnBedSaved = async (name, date, action) =>
                {
                    if (!string.IsNullOrWhiteSpace(name))
                    {
                        // ✅ Ensure new Bed objects receive `ViewModel`
                        MainThread.BeginInvokeOnMainThread(() =>
                        {
                            ViewModel.Beds.Add(new Bed(ViewModel)
                            {
                                Name = name,
                                LastChangeDate = date,
                                LastActionFlip = action == "Flipped"
                            });
                        });
                    }
                    else
                    {
                        var mainPage = Application.Current?.Windows.Count > 0 ? Application.Current.Windows[0].Page : null;
                        if (mainPage != null)
                        {
                            await mainPage.DisplayAlert("Error", "Bed name cannot be empty.", "OK");
                        }
                    }
                }
            };

            await this.ShowPopupAsync(popup);
        }

        // Open Popup when "Edit" is clicked
        private async void OnEditBedClicked(object sender, EventArgs e)
        {
            if (sender is Button button && button.BindingContext is Bed selectedBed)
            {
                var popup = new BedPopup
                {
                    OnBedSaved = async (name, date, action) =>
                    {
                        // Use MainThread.BeginInvokeOnMainThread to update UI
                        MainThread.BeginInvokeOnMainThread(() =>
                        {
                            selectedBed.Name = name;
                            selectedBed.LastChangeDate = date;
                            selectedBed.LastActionFlip = action == "Flipped";

                            ViewModel.RefreshBeds();
                        });

                        // Get the main page safely before using it
                        var mainPage = Application.Current?.Windows.Count > 0 ? Application.Current.Windows[0].Page : null;
                        if (mainPage != null)
                        {
                            await mainPage.DisplayAlert("Success", "Bed details updated successfully.", "OK");
                        }
                    }
                };

                await this.ShowPopupAsync(popup); // ✅ Ensure ShowPopup is awaited
            }
        }
    }
}
